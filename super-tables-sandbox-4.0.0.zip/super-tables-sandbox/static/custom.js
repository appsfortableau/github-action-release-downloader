// function ToggleColumns(arr) {
//   document.dispatchEvent(
//     new CustomEvent('toggle-columns', {
//       detail: arr,
//     })
//   );
// }

// let beforeDiv = document.getElementById('before_table');

// var button1 = document.createElement('BUTTON');
// button1.classList.add('myButton');
// button1.onclick = function () {
//   // ToggleColumns(['Customer Name']);
//   ToggleColumns(['CHANNEL']);
// };
// button1.innerHTML = 'Toggle CHANNEL';
// beforeDiv.appendChild(button1);

// var button1 = document.createElement('BUTTON');
// button1.classList.add('myButton');
// button1.onclick = function () {
//   // ToggleColumns(['Customer Name']);
//   ToggleColumns(['World']);
// };
// button1.innerHTML = 'Toggle World';
// beforeDiv.appendChild(button1);

// var button1 = document.createElement('BUTTON');
// button1.classList.add('myButton');
// button1.onclick = function () {
//   // ToggleColumns(['Customer Name']);
//   ToggleColumns(['Merlijn']);
// };
// button1.innerHTML = 'Toggle Merlijn';
// beforeDiv.appendChild(button1);

// var button1 = document.createElement('BUTTON');
// button1.classList.add('myButton');
// button1.onclick = function () {
//   // ToggleColumns(['Customer Name']);
//   ToggleColumns(['Test']);
// };
// button1.innerHTML = 'Toggle Test';
// beforeDiv.appendChild(button1);

// var button1 = document.createElement('BUTTON');
// button1.classList.add('myButton');
// button1.onclick = function () {
//   // ToggleColumns(['Customer Name']);
//   ToggleColumns(['Customer Name']);
// };
// button1.innerHTML = 'Toggle Customer Name';
// beforeDiv.appendChild(button1);

// // change popup button content
// let button = document.getElementsByClassName('openButton')[0];
// button.innerHTML = 'Hello World';
